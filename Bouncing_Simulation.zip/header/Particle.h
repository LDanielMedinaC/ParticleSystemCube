#pragma once
#ifdef _APPLE_
// For XCode only: New C++ terminal project. Build phases->Compile with libraries: add OpenGL and GLUT
// Import this whole code into a new C++ file (main.cpp, for example). Then run.
// Reference: https://en.wikibooks.org/wiki/OpenGL_Programming/Installation/Mac
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#endif
#ifdef _WIN32
// For VS on Windows only: Download CG_Demo.zip. UNZIP FIRST. Double click on CG_Demo/CG_Demo.sln
// Run
#include "freeglut.h"
#endif
#ifdef _unix_
// For Linux users only: g++ CG_Demo.cpp -lglut -lGL -o CG_Demo
// ./CG_Demo
// Reference: https://www.linuxjournal.com/content/introduction-opengl-programming
#include "GL/freeglut.h"
#include "GL/gl.h"
#endif
#ifndef _PARTICLE
#define _PARTICLE

#include <stdio.h>
#define _USE_MATH_DEFINES
#include <math.h>

class Particle {
public:
	float * position;
	float * oldPos;
	float mass;
	float * color;
	float radius;
	float * forces;
	float * dragForce;
	float area;
	float restitutionCoefficient;

	Particle(float rad, float m, float * p, float r, float g, float b);
	~Particle();
	void draw();
	void checkFloorCollision();
	void integrateVerlet(float dt);
	void update();
};
#endif // !_PARTICLE