#include "Particle.h"

Particle::Particle(float rad, float m, float * p, float r, float g, float b) {
	radius = rad;
	mass = m;
	position = new float[3];
	oldPos = new float[3];
	position[0] = oldPos[0] = p[0];
	position[1] = oldPos[1] = p[1];
	position[2] = oldPos[2] = p[2];

	color = new float[3];
	color[0] = r;
	color[1] = g;
	color[2] = b;

	forces = new float[3];
	forces[0] = forces[1] = forces[2] = 0;

	dragForce = new float[3];
	dragForce[0] = dragForce[1] = dragForce[2] = 0;

	area = M_PI*radius*radius;
	restitutionCoefficient = 0.8f;
}

Particle::~Particle() {}

void Particle::draw() {
	glPushMatrix(); {
		glTranslatef(position[0], position[1], position[2]);
		glColor3f(color[0], color[1], color[2]);
		glutWireSphere(radius, 20, 20);
	} glPopMatrix();
}

void Particle::integrateVerlet(float dt) {
	float * temp = new float[3];
	temp[0] = position[0];
	temp[1] = position[1];
	temp[2] = position[2];

	oldPos[0] = temp[0];
	oldPos[1] = temp[1];
	oldPos[2] = temp[2];

	float * accel = new float[3];
	accel[0] = (dragForce[0] + forces[0]) / mass;
	accel[1] = (dragForce[1] + forces[1]) / mass;
	accel[2] = (dragForce[2] + forces[2]) / mass;

	position[0] = (2 * position[0]) - oldPos[0] + accel[0] * dt * dt;
	position[1] = (2 * position[1]) - oldPos[1] + accel[1] * dt * dt;
	position[2] = (2 * position[2]) - oldPos[2] + accel[2] * dt * dt;

	//printf("%.3f, %.3f, %.3f\n", position[0], position[1], position[2]);
}

void Particle::checkFloorCollision() {
	if (position[1] <= radius) {
		position[1] = radius + radius / 100.f;
		forces[1] = -forces[1] * restitutionCoefficient;
	}
}

void Particle::update() {
	forces[1] += (-9.81*mass / 60.f);
	integrateVerlet(0.02);
	checkFloorCollision();
}

